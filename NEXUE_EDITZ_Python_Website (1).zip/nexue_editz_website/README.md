# NEXUE&EDITZ website

A responsive green-and-black anime-edit landing page built with Python Flask.

## Run locally
1. Install Python 3.
2. Open a terminal in this folder.
3. Run: `python -m pip install -r requirements.txt`
4. Run: `python app.py`
5. Open `http://127.0.0.1:5000` in your browser.

## Customize
- Open `templates/index.html` and replace the `#` in the Subscribe button with your YouTube channel URL.
- Replace the sample edit cards with your real video titles and links.
- Edit colors and layout in `static/style.css`.
